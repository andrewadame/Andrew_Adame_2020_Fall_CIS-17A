/* 
 * File: AI Test Output Format
 * Author: Andrew Adame
 * Date: 6/27/2020
 * Purpose: Create a program that matches the expected output.
 * Version: 1
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) 
{
    //DECLARING VARIABLES
    int num;
    
    //OUTPUT RESULTS
    cin >> num;
    cout << num << endl;
    cout << num << "." << num << endl;
    cout << "Hello World     " << endl;
    cout << "\tTab it!" << endl;
    cout << "Compare . . . to space   ";
    
    return 0;
}