
/* 
 * File:   main.cpp
 * Author: andre
 *
 * Created on November 12, 2020, 6:32 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

